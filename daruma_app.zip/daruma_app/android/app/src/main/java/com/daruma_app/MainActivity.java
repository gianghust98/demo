package com.daruma_app;

import com.reactnativenavigation.NavigationActivity;

public class MainActivity extends NavigationActivity {

  
}
